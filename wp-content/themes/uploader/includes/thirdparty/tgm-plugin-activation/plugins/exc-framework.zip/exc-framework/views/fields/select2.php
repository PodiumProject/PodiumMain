
<div class="form-group">
	<label for="<?php echo $name;?>"><?php echo $label;?></label>
	<?php echo $markup;?>
	
	<?php if($help):?>
	<p><?php echo $help;?></p>
	<?php endif;?>
</div>